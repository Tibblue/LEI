# Generated from gramatica.g4 by ANTLR 4.7.1
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .gramaticaParser import gramaticaParser
else:
    from gramaticaParser import gramaticaParser

# This class defines a complete listener for a parse tree produced by gramaticaParser.
class gramaticaListener(ParseTreeListener):

    # Enter a parse tree produced by gramaticaParser#dsl.
    def enterDsl(self, ctx:gramaticaParser.DslContext):
        pass

    # Exit a parse tree produced by gramaticaParser#dsl.
    def exitDsl(self, ctx:gramaticaParser.DslContext):
        pass


    # Enter a parse tree produced by gramaticaParser#create_block.
    def enterCreate_block(self, ctx:gramaticaParser.Create_blockContext):
        pass

    # Exit a parse tree produced by gramaticaParser#create_block.
    def exitCreate_block(self, ctx:gramaticaParser.Create_blockContext):
        pass


    # Enter a parse tree produced by gramaticaParser#create_bot.
    def enterCreate_bot(self, ctx:gramaticaParser.Create_botContext):
        pass

    # Exit a parse tree produced by gramaticaParser#create_bot.
    def exitCreate_bot(self, ctx:gramaticaParser.Create_botContext):
        pass


    # Enter a parse tree produced by gramaticaParser#states.
    def enterStates(self, ctx:gramaticaParser.StatesContext):
        pass

    # Exit a parse tree produced by gramaticaParser#states.
    def exitStates(self, ctx:gramaticaParser.StatesContext):
        pass


    # Enter a parse tree produced by gramaticaParser#dataset.
    def enterDataset(self, ctx:gramaticaParser.DatasetContext):
        pass

    # Exit a parse tree produced by gramaticaParser#dataset.
    def exitDataset(self, ctx:gramaticaParser.DatasetContext):
        pass


