def responde():
    frase = 'Não falo mais contigo.'
    return frase